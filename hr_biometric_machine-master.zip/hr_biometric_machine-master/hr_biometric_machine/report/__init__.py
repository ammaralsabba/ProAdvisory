# -*- coding: utf-8 -*-

import daily_attendance
